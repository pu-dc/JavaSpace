package inherit;

public class SuperPerson {
	protected int id;
	protected String name;

	public SuperPerson(int id, String name) {
		this.id 	= id;
		this.name 	= name;
	}
}