package inherit;

public class SuperMaster {
	public static void main(String[] args) {
		SuperEmployee se = new SuperEmployee(1, "Adam Mustoriq", 15000000l);
		se.display();
	}
}