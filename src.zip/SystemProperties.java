/**
 *
 * @author 4rcherry
 * 2018 © PUDC
**/

public class SystemProperties {
    public SystemProperties() {}
    public static void main(String args[]) {
        System.getProperties().list(System.out);
    }
}