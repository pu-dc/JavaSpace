<!--
		C O N T E N T S
							-->

**_ ATTENTION _**
*----------------
Make Sure That You'Ve Done Read These Chapters Before You Ready For The Next Chapter
	BAB 1 		: Java Introduction
	BAB 2		: Java Fitures
	BAB 3 		: Java Development Kit
You Will be Able to Find These Chapters From Blog / Wikipedia
----------------*

BAB 4		: First Java progam [OK]
BAB 5		: Token and Literal [OK]
BAB 6 		: Separator, Whitespace, dan Comment [OK]
BAB 7		: Data types [OK]
BAB 8		: Konvension and Data type casting
BAB 9		: Operator
BAB 10		: Operator Integer
BAB 11		: Floating Point operator
BAB 12		: Operator Boolean
BAB 13		: Operator String
BAB 14		: Operator Assignment and Otomation types
BAB 15		: Array
BAB 16		: Block and Environment
BAB 17		: Sekuen
BAB 18		: Branching
BAB 19		: Loop
BAB 20		: Jump
BAB 21		: Class
BAB 22		: Methode
BAB 23 		: Constructor
BAB 24		: Object
BAB 25		: Class Object
BAB 26 		: Approximate of Object Oriented
BAB 27		: Encapsulation
BAB 28		: Inheritance
BAB 29		: Polymorphism
BAB 30		: Message
	
**To Be Comming Soon**
*---------------------
	BAB 31		: String
	BAB 32		: Class StringBuffer
	BAB 33		: Class Math
	BAB 34		: Class Data Type Wrapper
	BAB 35		: BigInteger dan BigDecimal
	BAB 36		: Package
	BAB 37		: Exeption Handling
	BAB 38		: Inner Class
	BAB 39		: Interface
	BAB 40		: Reflection
	BAB 41		: Multithreading
	BAB 42		: Package Java.Lang
	BAB 43		: Console Application
	BAB 44		: Applet
	BAB 45		: Windowing on Java
	BAB 46		: What is Next?
---------------------*

#Version 1.1.2
#Created	: 2018 07 18
#Updated	: 2018 09 11