package object;

public class NaturalSequence extends IntegerSequence {
	public NaturalSequence() {
		super();
	}
	public void next() {
		value++;
		th++;
	}
}