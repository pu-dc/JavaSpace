class Circle {
	public static void main(String[] args) {
		double pi, radius, area;

		radius = 10.98;
		pi = 3.1416;
		area = pi * radius * radius;

		System.out.printf("Luas lingkaran berjari-jari %d adalah %d", radius, area);
	}
}